
public class MySingleton {
	private static MySingleton instance = new MySingleton();
	
	private MySingleton() {}
	
	public static MySingleton getInstances() {
		return instance;
	}
	
	public void test() {
		System.out.println("Hallo");
	}

}

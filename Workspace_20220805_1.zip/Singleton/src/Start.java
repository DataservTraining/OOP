
public class Start {

	private int x = 8;
	private static int y = 10;
	public static void main(String[] args) {
		MySingleton singleton = MySingleton.getInstances();
		Start start = new Start();
	//	System.out.println(x); Zugriff auf Objektattribut x nicht möglich aus statischem Kontext
		System.out.println(y);
		singleton.test();
		test2();
		
	}
	
	public static void test2() {
		System.out.println("test2");
	}

	public void test3() {
		System.out.println("test3: " + x);
		System.out.println("test3: " + y);
	}

}

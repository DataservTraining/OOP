package uebungfahrzeug;

public class Start {

	public static void main(String[] args) {

		Fahrzeug pkw1 = new Fahrzeug("BMW", "Blau", 5, 210, 10.0, 100);
		pkw1.show();
		
		double strecke = 2500;
		pkw1.tanken();
		pkw1.show();
		
		while (strecke > 0) {
			strecke = pkw1.fahren(strecke);
			pkw1.show();
			pkw1.tanken();
			pkw1.show();
		}
		

	}

}

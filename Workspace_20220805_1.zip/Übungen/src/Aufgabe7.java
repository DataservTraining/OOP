
public class Aufgabe7 {

	public static void main(String[] args) {
		String leer = "";
		for(int zeile = 0; zeile < 10; ++zeile) {
			for(int spalte = 1; spalte < 11; ++spalte) {
				int zahl = zeile*10 + spalte;
				leer = zahl < 10 ? "     " : zahl < 100 ? "    " : "   ";
				System.out.print(leer + zahl );
			}
			System.out.println();
		}
		System.out.println("===================================");
		for(int zahl = 1; zahl < 101; ++zahl) {
			leer = zahl < 10 ? "  00" : zahl < 100 ? "  0" : "  ";
			System.out.print(leer + zahl);
			if(zahl % 10 == 0) {
				System.out.println();
			}
		}

		System.out.println("===================================");
		for(int zahl = 1; zahl < 101; ++zahl) {
			System.out.printf("  %03d", zahl);
			if(zahl % 10 == 0) {
				System.out.println();
			}
		}
	}

}

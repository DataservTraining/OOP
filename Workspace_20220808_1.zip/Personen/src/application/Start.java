package application;
import java.util.ArrayList;

import entities.Person;


public class Start {

	public static void main(String[] args) {
		
		Person p = new Person();
		p.show();
		
		p.setVorname("Willi");
		p.setName("Wuff");
		p.setAlter(150);
		String vornameVonWilli = p.getVorname();
		//int x = 4.5;
		int alterVonWilli = p.getAlter();
//		System.out.println(p.alter);
		p.essen();
		String text = "Fleisch";
		p.essen(text);
		
		p.show();
		
		Person p2 = new Person("Donald", "Duck", 120);
//		p2.vorname = "Donald";
//		p2.name = "Duck";
//		p2.alter = 180;
		p2.essen();
		p2.essen("Salat");
		
		p2.show();		
		
		System.out.println(true);

	}

}

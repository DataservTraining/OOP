
public class Flugzeug extends Fahrzeug {
	
	private int spannweite;
	private int anzahlTriebwerke;
	
	public Flugzeug() {
		this("unbekannt", "unbekannt", 0, 0, 0.0, 0, 0, 0);
	}
	
	public Flugzeug(String hersteller, String farbe, int anzahlSitze, int ps, double verbrauchPro100, 
			int maxTankinhalt, int anzahlTriebwerke, int spannweite) {
		super(hersteller, farbe, anzahlSitze, ps, verbrauchPro100, maxTankinhalt);
		setAnzahlTriebwerke(anzahlTriebwerke);
		setSpannweite(spannweite);
	}
	
	public void starten() {
		
	}
	
	public void landen() {
		
	}
	
	public int getSpannweite() {
		return spannweite;
	}
	public void setSpannweite(int spannweite) {
		this.spannweite = spannweite;
	}
	public int getAnzahlTriebwerke() {
		return anzahlTriebwerke;
	}
	public void setAnzahlTriebwerke(int anzahlTriebwerke) {
		this.anzahlTriebwerke = anzahlTriebwerke;
	}
	
	

}

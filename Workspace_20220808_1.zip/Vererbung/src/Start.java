import java.util.Scanner;

public class Start {

	public static void main(String[] args) {
		Fahrzeug fahrzeug = null;
		System.out.println("Flugzeug oder Fahrzeug?");
		Scanner scanner = new Scanner(System.in);
		int antwort = scanner.nextInt();
		if(antwort == 1) {
			fahrzeug = new Fahrzeug();
			((Flugzeug)fahrzeug).setSpannweite(90);
		} else {
			// "Boing", "Silber", 130, 12000, 1000, 30000
			fahrzeug = new Flugzeug();
			((Flugzeug)fahrzeug).setSpannweite(45);
			System.out.println(((Flugzeug)fahrzeug).getSpannweite());
		}
		
//		for(Fahrzeug f : fahrzeuge) {
//			f.wartungsplanDrucken();
//		}
		
		fahrzeug.show();
	}

}

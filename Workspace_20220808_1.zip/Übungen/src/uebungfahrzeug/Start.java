package uebungfahrzeug;

public class Start {

	public static void main(String[] args) {
		final int x =34;
//		X = 23; nicht möglich, da final
		Fahrzeug pkw1 = new Fahrzeug("BMW", "Blau", 5, 210, 10.0, 100);
		pkw1.show();
		
		double strecke = 2500;
		pkw1.tanken();
		pkw1.show();
		
		while (strecke > 0) {
			strecke = pkw1.fahren(strecke);
			pkw1.show();
			pkw1.tanken();
			pkw1.show();
		}
		
		System.out.println("=====================================");
		
		testFahrzeug(pkw1);
		pkw1.show();

	}
	
	public static void testFahrzeug(final Fahrzeug f) {
		f.setAnzahlSitze(20);
	}
	
	public static void test(final int Y) {
		//Y = 34; nicht möglich, da final
	}

}


public class Verzweigungen {

	public static void main(String[] args) {
		int wert1 = 18;
		// einseitige Verzweigung
		if (wert1 < 0) {
			System.out.println("wert1 zu klein in einseitiger Verzw.");
		}
		// zweiseitige Verzweigung		
		if (wert1 < 0) {
			System.out.println("wert1 zu klein  in zweiseitiger Verzw.");
		} else {
			wert1 *= 2;
			System.out.println(wert1);
		}

		// mehrstufige  Verzweigung erste Variante
		if (wert1 < 0) {
			System.out.println("wert1 zu klein  in mehrstufiger Verzw.");
		} else {
			if(wert1 < 10 ) {
				wert1 *= 2;
				System.out.println(wert1);
			} else {
				if (wert1 < 20) {
					wert1 *= 3;
					System.out.println(wert1);
				}
			}
		}
		
		// mehrstufige  Verzweigung zweite Variante
		if (wert1 < 0) {
				System.out.println("wert1 zu klein");
		} else if(wert1 < 10 ) {
				wert1 *= 2;
				System.out.println(wert1);
		} else if (wert1 < 20){
				wert1 *= 3;
				System.out.println(wert1);
		} else {
				System.out.println("wert1 > 20");
		}
		
		// mehrseitige Verzweigung
		int note = 2;
		
		switch (note) {
			case 1:
				System.out.println("Die Note ist: ");
				System.out.println("sehr gut");
				break;
			case 2:
				System.out.println("gut");
				break;
			case 3:
				System.out.println("befriedigend");
				break;
			case 4:
				System.out.println("ausreichend");
				break;
			case 5:
				System.out.println("mangelhaft");
				break;
			case 6:
				System.out.println("ungenügend");
				break;
			default:
				System.out.println("ungültige Note");
		}
		
		switch (note) {
		case 1:
		case 2:
		case 3:
		case 4:
			System.out.println("bestanden");
			break;
		case 5:
		case 6:
			System.out.println("nicht bestanden");
			break;
		default:
			System.out.println("ungültige Note");
	}
		
		switch (note) {
		case 5:
		case 6:
			System.out.print("nicht ");
		case 1:
		case 2:
		case 3:
		case 4:
			System.out.println("bestanden");
			break;
		default:
			System.out.println("ungültige Note");
	}
		
		
	}

}

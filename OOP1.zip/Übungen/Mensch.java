
public class Mensch {
	
	private String name;
	private String vorname;
	private Integer alter;
	private String geschlecht;
	
	public Mensch() {
		this("unbekannt","unbekannt",null,"unbekannt");
	}
	
	public Mensch(String name) {
		this(name,"unbekannt",null,"unbekannt");
	}
	
	public Mensch(String name, String vorname, Integer alter, String geschlecht) {
		this.name = name;
		this.vorname = vorname;
		this.alter = alter;
		this.geschlecht = geschlecht;		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public Integer getAlter() {
		return alter;
	}

	public void setAlter(Integer alter) {
		this.alter = alter;
	}

	public String getGeschlecht() {
		return geschlecht;
	}

	public void setGeschlecht(String geschlecht) {
		this.geschlecht = geschlecht;
	}
	
	

}


public class MenschTest {

	public static void main(String[] args) {

		Mensch m1 = new Mensch("Scholz");
		
		System.out.println(m1.getName());

	}

}

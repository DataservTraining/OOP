package rationalezahlen;

public class Start {

	public static void main(String[] args) {
		Bruch b1 = new Bruch(2,4);
		Bruch b2 = new Bruch(2,4);
		Bruch b3 = b1.addieren(b2);
		Bruch b4 = b1.multiplizieren(b2);
		
		b1.show();
		System.out.println();
		b2.show();
		System.out.println();
		b3.show();
		System.out.println();
		b4.show();
		System.out.println();
		
		int a = 9, b = 5;
		System.out.println("a: " + a + "\tb: " + b);
		swap(a, b);
		System.out.println("a: " + a + "\tb: " + b);
	}
	
	public static void swap(int x, int y) {
		System.out.println("x: " + x + "\ty: " + y);
		int temp = x;
		x = y;
		y = temp;
		System.out.println("x: " + x + "\ty: " + y);
	}

}

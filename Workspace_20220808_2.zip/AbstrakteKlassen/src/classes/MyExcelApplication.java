package classes;

public class MyExcelApplication extends AbstractApplication {

	@Override
	protected Document createDocument() {
		return new ExcelDocument();
	}

}

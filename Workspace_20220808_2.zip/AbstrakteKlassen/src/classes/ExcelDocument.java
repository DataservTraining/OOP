package classes;

public class ExcelDocument extends Document {

	@Override
	public void save() {
		System.out.println("Tabellen-Dokument gespeichert");

	}

}

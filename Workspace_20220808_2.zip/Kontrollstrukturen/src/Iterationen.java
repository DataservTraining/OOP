
public class Iterationen {

	public static void main(String[] args) {
		
		for (
				int zaehler = 1, y = 9;
				zaehler <= 100; 
				zaehler += 1, y +=10) 
		{
			System.out.println("Zähler: " + zaehler + "\ty: " + y);
//			zaehler--;
		}
		
		int x = 150;
		
		while(x < 100) {
			System.out.println("x in While(): " + x);
			++x;
		}
		
		int y = 60;
		
		do {		
			System.out.println("y in do-While(): " + y);
			++y;
		}while(y < 100);

	}

}

import java.util.Scanner;

public class Einlesen {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Einlesen double: ");
		double d = scanner.nextDouble();
		System.out.println("Einlesen int: ");
		int i = scanner.nextInt();
		
		System.out.println("double: " + d);
		System.out.println("int: " + i);
		

	}

}

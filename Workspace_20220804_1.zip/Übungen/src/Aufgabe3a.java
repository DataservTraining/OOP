import java.util.Scanner;

public class Aufgabe3a {

	public static void main(String[] args) {
		double zahl2 = 0;
		double ergebnis = 0;
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("bitte 1. Zahl eingeben: ");
		double zahl1 = scanner.nextDouble();
		System.out.println("bitte Operator eingeben: ");
		scanner.nextLine();
		String op = scanner.nextLine().substring(0, 1);
//		char op1 = scanner.nextLine().charAt(0);
		
		if(!"!".equals(op)) {
			System.out.println("bitte 2. Zahl eingeben: ");
			zahl2 = scanner.nextDouble();
		}
		
		switch(op) {
		case "+":
				ergebnis = zahl1 + zahl2;
				break;
		case "-":
			ergebnis = zahl1 - zahl2;
			break;
		case "*":
			ergebnis = zahl1 * zahl2;
			break;
		case "/":
			if(zahl2 != 0) {
				ergebnis = zahl1 / zahl2;
			} else {
				System.out.println("Division durch 0 nicht erlaubt!");
			}
			break;
		case "^":
					ergebnis = 1;
					for(int zaehler = 1; zaehler <= zahl2; ++zaehler) {
						ergebnis *= zahl1;
					}
					break;
		case "!":
			ergebnis = 1;
			for(int faktor = (int)zahl1; faktor > 1; --faktor) {
				ergebnis *= faktor;
			}
			break;
		default:
			System.out.println("keine gültige Rechenoperation");
		}
		
		if(!"!".equals(op)) {
			System.out.printf("Ergebnis: %.3f %s %.3f = %.3f\n ", zahl1, op, zahl2, ergebnis);
		} else if("!".equals(op)) {
			System.out.printf("Ergebnis: %.0f%s = %.0f\n ", zahl1, op, ergebnis);
		}

	}

}

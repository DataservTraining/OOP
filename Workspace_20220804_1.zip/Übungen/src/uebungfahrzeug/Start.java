package uebungfahrzeug;

public class Start {

	public static void main(String[] args) {
		Fahrzeug pkw1 = new Fahrzeug();
		pkw1.show();
		
		Fahrzeug pkw2 = new Fahrzeug("Audi", "Schwarz", 2800, 190);
		pkw2.show();

	}

}

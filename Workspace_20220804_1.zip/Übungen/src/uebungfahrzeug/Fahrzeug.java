package uebungfahrzeug;

public class Fahrzeug {

	public String hersteller;
	public String farbe;
	public int hubraum;
	public int ps;
	
	public Fahrzeug() {
		this("unbekannt", "unbekannt", 0, 0);
	}
	
	public Fahrzeug(String hersteller, String farbe, int hubraum, int ps) {
		this.hersteller = hersteller;
		this.farbe = farbe;
		this.hubraum = hubraum;
		this.ps = ps;
	}
	
	public void show() {
		System.out.printf("Hersteller: %s\n", hersteller);
		System.out.printf("Farbe:      %s\n", farbe);
		//System.out.println("Farbe:      " + farbe);
		System.out.println("Hubraum:    " + hubraum + " ccm");
		System.out.println("PS:         " + ps);
	}

}

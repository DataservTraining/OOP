import java.util.Scanner;

public class Aufgabe1b {

	public static void main(String[] args) {
		int zahl = -1;
		int summe = 0;
		int anzahl = 0;
		double mittelwert = 0;
		
		Scanner scanner = new Scanner(System.in);
		
		while (zahl != 0){
			System.out.println("Einlesen Zahl: ");
			zahl = scanner.nextInt();
			summe += zahl;
			++anzahl;
		}
		--anzahl;
		System.out.println("Summe: " + summe);
		if(anzahl != 0) {
			mittelwert = (double) summe / anzahl;
			System.out.println("Mittelwert: " + mittelwert);
		} else {
			System.out.println("Mittelwert kann nicht ermittelt werden");
		}
	}

}

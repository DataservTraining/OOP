package entities;



public class Person {
	private String vorname;
	private String name;
	private int alter;
	
	public Person() {
		this("unbekannt", "unbekannt", 0);
	}
	
	public Person(String vorname, String name, int alter) {
		this.vorname = vorname;
		this.name = name;
		setAlter(alter);
	}
	
	public String getVorname() {
		return vorname;
	}

	public String getName() {
		return name;
	}
	
	public int getAlter() {
		return alter;
	}
	
	public void setVorname(String vorname) {
		this.vorname = vorname;
	}
	public void setName(String name) {
//		String regex = "[a-zA-Z,-, ]*";
//		String regex2 = "^[0-9a-zA-Z\\-\\_\\.]+[@][0-9a-zA-Z\\-\\_\\.]+[\\.][a-zA-Z]+[\\.]{0,1}[a-zA-Z]{0,3}";
		this.name = name;
	}
	
	public void setAlter(int alter) {
		if(alter < 0 || alter > 120) {
			System.out.println("unzulässiger Wert für das Alter!");
			
			return;
		}
		this.alter = alter;
	}
	
	public void essen() {
		System.out.println(vorname + " isst.");
	}
	
	public void essen(String nahrung) {
		System.out.println(this.vorname + " isst " + nahrung);
	}
	
	public void show() {
		System.out.printf("Name:  %s %s\n", vorname, name);
		System.out.printf("Alter: %d\n\n" , alter);
	}
}


public class Verzweigungen {

	public static void main(String[] args) {
		int wert1 = 18;
		// einseitige Verzweigung
		if (wert1 < 0) {
			System.out.println("wert1 zu klein in einseitiger Verzw.");
		}
		// zweiseitige Verzweigung		
		if (wert1 < 0) {
			System.out.println("wert1 zu klein  in zweiseitiger Verzw.");
		} else {
			wert1 *= 2;
			System.out.println(wert1);
		}

		// mehrstufige  Verzweigung erste Variante
		if (wert1 < 0) {
			System.out.println("wert1 zu klein  in mehrstufiger Verzw.");
		} else {
			if(wert1 < 10 ) {
				wert1 *= 2;
				System.out.println(wert1);
			} else {
				if (wert1 < 20) {
					wert1 *= 3;
					System.out.println(wert1);
				}
			}
		}
		
		// mehrstufige  Verzweigung zweite Variante
		if (wert1 < 0) {
				System.out.println("wert1 zu klein");
		} else if(wert1 < 10 ) {
				wert1 *= 2;
				System.out.println(wert1);
		} else if (wert1 < 20){
				wert1 *= 3;
				System.out.println(wert1);
		} else {
				System.out.println("wert1 > 20");
		}
		
	}

}

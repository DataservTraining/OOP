package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

public class MyApplicationController implements Initializable {
	ResourceBundle resources;
	@FXML
	private Button btnFirstButton;

	@FXML
	private Button btnSecondButton;

	@FXML
	void btnFirstButtonHandler(ActionEvent event) {

		btnFirstButton.setText(resources.getString("window_title"));

	}

	@FXML
	void btnSecondButtonHandler(ActionEvent event) {

	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		this.resources = resources;
	}

}

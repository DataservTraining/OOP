package BuilderPattern;

import java.util.List;

import abstractfactory.Lebensmittel;

public class ClassicPizzaBuilder implements Builder{

	Pizza pizza;
	
	public void provideLebensmittel(Lebensmittel lebensmittel)
	{
		pizza=(Pizza) lebensmittel;
	}
	
	
	
	public Builder addCheese() {
		
		pizza.setCheese();
		return this;
	}

	
	public Builder addTomato() {
		pizza.setTomato();
		return this;
	}

	
	public Builder addMushroom() {
		pizza.setMushroom();
		return this;
	}

	
	public Builder addPineApple() {
		pizza.setPineApple();
		return this;
	}

	

	@Override
	public Builder build(List<Zutaten> zutaten) {
		for(Zutaten zutat : zutaten) {
			switch(zutat) {
			case CHEESE:
				addCheese();
				break;
			case TOMATO:
				addTomato();
				break;
			case MUSHROOM:
				addMushroom();
				break;
			case PINEAPPLE:
				addPineApple();
				break;
			default:
				break;
			}
		}
		return this;
	}


	@Override
	public Pizza get() {
		return pizza;
	}
	
}


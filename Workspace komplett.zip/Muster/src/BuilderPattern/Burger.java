package BuilderPattern;

import abstractfactory.Lebensmittel;

public class Burger implements Lebensmittel{
	private boolean cheese;
	private boolean tomato;
	private boolean mushroom;
	private boolean salat;
	
	
	private String name;
	
	public Burger(String name)
	{
		this.name=name;
	}
	
	public String getName()
	{
		return name;
	}
	
	public void setSalat() {
		salat = true;
	}
	
	public void setCheese() {
		cheese = true;
	}
	
	
	public void setTomato() {
		tomato = true;
	}
	
	

	
	public void setMushroom() {
		mushroom=true;
	}
	
	
	public boolean hasCheese()
	{
		return cheese;
	}
	
	public boolean hasMushroom()
	{
		return mushroom;
	}
	
	
	public boolean hasSalat() {
		return salat; 
	}
	public boolean hasTomato()
	{
		return tomato;
	}


	public void getDescription()
	{
		System.out.println("Burger description");
		System.out.println("Burger Order name : "+this.getName());
		System.out.println("Cheese : "+this.hasCheese());
		System.out.println("Tomato : "+this.hasTomato());
		System.out.println("Mushroom : "+this.hasMushroom());
		System.out.println("Salat : "+this.hasSalat());
	}

	@Override
	protected Object clone()  {
		Burger temp = new Burger(this.name);
		if(this.cheese) temp.setCheese();
		if(this.mushroom) temp.setMushroom();
		if(this.salat) temp.setSalat();
		if(this.tomato) temp.setTomato();
		return temp;
	}
	
	
}

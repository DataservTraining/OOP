package BuilderPattern;

import java.util.List;

import abstractfactory.Lebensmittel;

public interface Builder {
	
	public void provideLebensmittel(Lebensmittel lebensmittel);

	public Builder build(List<Zutaten> zutaten);
	
	public Lebensmittel get();
}

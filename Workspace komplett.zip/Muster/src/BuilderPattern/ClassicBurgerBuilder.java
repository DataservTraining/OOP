package BuilderPattern;

import java.util.List;

import abstractfactory.Lebensmittel;

public class ClassicBurgerBuilder implements Builder {

	Burger burger;

	public void provideLebensmittel(Lebensmittel lebensmittel) {
		burger = (Burger) lebensmittel;
	}

	public Builder addCheese() {

		burger.setCheese();
		return this;
	}

	public Builder addTomato() {
		burger.setTomato();
		return this;
	}

	public Builder addMushroom() {
		burger.setMushroom();
		return this;
	}

	public Builder addSalat() {
		burger.setSalat();
		return this;
	}

	

	@Override
	public Builder build(List<Zutaten> zutaten) {
		for (Zutaten zutat : zutaten) {
			switch (zutat) {
			case CHEESE:
				addCheese();
				break;
			case TOMATO:
				addTomato();
				break;
			case MUSHROOM:
				addMushroom();
				break;
			case SALAT:
				addSalat();
				break;
			default:
				break;
			}
		}
		return this;
	}

	@Override
	public Burger get() {
		return burger;
	}

}

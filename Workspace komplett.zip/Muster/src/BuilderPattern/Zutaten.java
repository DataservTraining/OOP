package BuilderPattern;

public enum Zutaten {
	CHEESE,
	TOMATO,
	PINEAPPLE,
	MUSHROOM,
	SALAT
}

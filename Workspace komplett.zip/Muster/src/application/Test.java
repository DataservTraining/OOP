package application;

import static BuilderPattern.Zutaten.CHEESE;
import static BuilderPattern.Zutaten.MUSHROOM;
import static BuilderPattern.Zutaten.PINEAPPLE;
import static BuilderPattern.Zutaten.TOMATO;
import static BuilderPattern.Zutaten.SALAT;

import java.util.Arrays;

import BuilderPattern.Builder;
import BuilderPattern.Burger;
import BuilderPattern.ClassicBurgerBuilder;
import BuilderPattern.ClassicPizzaBuilder;
import BuilderPattern.Pizza;
import abstractfactory.BurgerFabrik;



public class Test {
	
	/*
	 
	 Problems without builder pattern 
	 
	1) too many constructors to maintain.
    2) You can partially solve this problem by creating Pizza and then adding
    ingredients but that will impose another problem of leaving Object on
    inconsistent state during building, ideally cake should not be available until its created.
    Both of these problem can be solved by using Builder design pattern in Java. 
    Builder design pattern not only improves readability but also reduces chance of error by adding ingredients 
    explicitly and making object available ONCE FULLY CONSTRUCTED. 
    
	 */

	public static void main(String[] args)
	{
		Builder builder=new ClassicPizzaBuilder();
		
		Pizza p1= new Pizza("Rohit Singh");
		Pizza p2=new Pizza("Alok Pandey");
		
		builder.provideLebensmittel(p1);
		
		p1= (Pizza) builder.build(Arrays.asList(CHEESE, TOMATO))
				  .get();
		
		builder.provideLebensmittel(p2);
		
		p2=(Pizza) builder.build(Arrays.asList(CHEESE, MUSHROOM, PINEAPPLE, TOMATO))
				  .get();
		
		
		p1.getDescription();
		
		System.out.println();
		
		p2.getDescription();
		
		Burger burger1 = new BurgerFabrik().erzeuge("Cheese-Burger");
		builder = new ClassicBurgerBuilder();
		builder.provideLebensmittel(burger1);
		burger1 = (Burger)builder.build(Arrays.asList(CHEESE, SALAT)).get();
		burger1.getDescription();
	
		
		       
	}
//	
//	
//	public static void getDescription(Pizza pizza)
//	{
//		System.out.println("Pizza description");
//		System.out.println("Pizza Order name : "+pizza.getName());
//		System.out.println("Cheese : "+pizza.hasCheese());
//		System.out.println("Tomato : "+pizza.hasTomato());
//		System.out.println("Mushroom : "+pizza.hasMushroom());
//		System.out.println("PineApple : "+pizza.hasPineApple());
//	}
//	
}


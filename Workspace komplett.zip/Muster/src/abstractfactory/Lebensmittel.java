package abstractfactory;

public interface Lebensmittel {

}

package abstractfactory;

public interface AbstrakteFabrik {
	public Lebensmittel erzeuge(String name);
}

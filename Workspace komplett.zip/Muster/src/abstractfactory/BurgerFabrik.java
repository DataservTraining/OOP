package abstractfactory;

import BuilderPattern.Burger;

public class BurgerFabrik implements AbstrakteFabrik {

	@Override
	public Burger erzeuge(String name) {
		return new Burger(name);
	}

}

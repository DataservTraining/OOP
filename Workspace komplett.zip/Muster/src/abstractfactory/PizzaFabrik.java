package abstractfactory;

import BuilderPattern.Pizza;

public class PizzaFabrik implements AbstrakteFabrik {

	@Override
	public Pizza erzeuge(String name) {
		return new Pizza(name);
	}


}

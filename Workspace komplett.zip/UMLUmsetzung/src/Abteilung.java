import java.util.ArrayList;
import java.util.List;

public class Abteilung {
	private List<Mitarbeiter> mitarbeiter;
	private Mitarbeiter chef = null;
	private List<Mitarbeiter> stellvertreter;

	public Abteilung() {
		super();
		mitarbeiter = new ArrayList<>();
	}

	public List<Mitarbeiter> getMitarbeiter() {
		return mitarbeiter;
	}

	
	public void addMitarbeiter(Mitarbeiter neuerMitarbeiter) {
		if(mitarbeiter.size() >= 100) {
			System.out.println("Abteilung voll");
			return;
		}
		if(neuerMitarbeiter.getRolle() == Rolle.CHEF) {
			chef = neuerMitarbeiter;
		}
		if(neuerMitarbeiter.getRolle() == Rolle.STELLVERTRETER ) {
			if(stellvertreter.size() < 2) {
				stellvertreter.add(neuerMitarbeiter);
			} else {
				stellvertreter.set(0, neuerMitarbeiter);
			}
		}
		
		mitarbeiter.add(neuerMitarbeiter);
	}
	
	

}


public class Mitarbeiter extends Person{
	private Abteilung arbeisplatz;
	private Rolle rolle;
	
	
	public Mitarbeiter() {
		this(null, Rolle.ANGESTELLTER);
	}
	public Mitarbeiter(Abteilung arbeisplatz, Rolle rolle) {
		super();
		this.arbeisplatz = arbeisplatz;
		this.rolle = rolle;
	}
	public Abteilung getArbeisplatz() {
		return arbeisplatz;
	}
	public void setArbeisplatz(Abteilung arbeisplatz) {
		this.arbeisplatz = arbeisplatz;
		arbeisplatz.addMitarbeiter(this);
	}
	public Rolle getRolle() {
		return rolle;
	}
	public void setRolle(Rolle rolle) {
		this.rolle = rolle;
	}
	
	
}

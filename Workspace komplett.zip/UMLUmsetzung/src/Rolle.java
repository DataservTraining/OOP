
public enum Rolle {
	ANGESTELLTER, STELLVERTRETER, CHEF 
}

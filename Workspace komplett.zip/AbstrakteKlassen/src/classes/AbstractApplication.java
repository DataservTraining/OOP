package classes;

public abstract class AbstractApplication {
	private Document[] documents;
	private int index;
	
	public AbstractApplication() {
		documents = new Document[10];
	}
	
	public void newDocument() {
		if(index < 10) {
			Document doc = createDocument();
			documents[index] = doc;
			index++;
			doc.save();
		} else {
			System.out.println("Es können keine weiteren Dokumente angelegt werden.");
		}
	}
	
	protected abstract Document createDocument();
}

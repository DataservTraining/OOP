package application;
import classes.AbstractApplication;
import classes.MyExcelApplication;
import classes.MyWordApplication;

public class Start {

	public static void main(String[] args) {
//		AbstractApplication app = new AbstractApplication();
		AbstractApplication word = new MyWordApplication();
		word.newDocument();
		AbstractApplication excel = new MyExcelApplication();
		excel.newDocument();
	}

}

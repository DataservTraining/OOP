
public class Start {

	public static void main(String[] args) {
		MyArrayList<String> strings = new MyArrayList<>();
		strings.add("Hallo");
		strings.add("Welt");
		System.out.println(strings.get(0));
		System.out.println(strings.get(1));
		
		MyArrayList<Integer> integers = new MyArrayList<>();
		integers.add(34);
		integers.add(12);
		System.out.println(integers.get(0));
		System.out.println(integers.get(1));
	}

}

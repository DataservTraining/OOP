import java.util.Arrays;

public class MyArrayList <T> {
	
	private T[] daten;
	private int index;
	
	@SuppressWarnings("unchecked")
	public MyArrayList() {
		daten = (T[])new Object[10];
	}
	
	public void add(T element) {
		if(index == daten.length) {
			daten = Arrays.copyOf(daten, daten.length * 2);
		}
		daten[index++] = element;
	}
	
	public T get(int i) {
		if(i > -1 && i < index) {
			return daten[i];
		}
		return null;
	}

}

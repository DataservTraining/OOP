package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class TestController {

    @FXML
    private Button btnButton;
    
    

    @FXML
    void handleBtnButtonAction(ActionEvent event) {
    	btnButton.setText("??????");
    }

}


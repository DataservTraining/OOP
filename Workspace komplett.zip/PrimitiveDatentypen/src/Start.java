import java.math.BigInteger;

public class Start {
	
	public static void main(String[] args) {
		byte erstesByte, zweitesByte = 34;
		erstesByte = 127;
		short ersterShort = 2323;
		int ersterInt = 2100000000;
		long ersterLong = 837482746387L;
		ersterLong = 3000000000L;
		int erg = ersterInt * 2;
		System.out.println(erg);
		
		float ersterFloat = 23.5F;
		double ersterDouble = 435.56;
		
		boolean ok = true; // false
		
		char ch = 'A';
		System.out.println(ch);
		ch = 57;
		System.out.println(ch);
		ch ='\u0041';
		System.out.println(ch);
		
		ersterInt = 0xFF00FF;
		
	}

}

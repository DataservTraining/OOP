package application;

import java.util.ResourceBundle;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MyApplication extends Application{

	public static void main(String[] args) {
		launch(args);

	}

	@Override
	public void start(Stage primaryStage) throws Exception {
//		Locale.setDefault(Locale.ENGLISH);
	
		ResourceBundle resources = ResourceBundle.getBundle("application.language.resources");
		
		
		// Zuweisung des Controllers im Quellcode
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/gui/startscreen.fxml"));
		loader.setController(new MyApplicationController());
		loader.setResources(resources);
		Parent root = loader.load();
		
		Scene scene = new Scene(root, 1000, 600);
		scene.getStylesheets().add("/application/gui/styles/main.css");
		primaryStage.setScene(scene);
		primaryStage.setTitle(resources.getString("window.title"));
		primaryStage.show();
	}
	
	

}

package entities;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.paint.Color;

public class Rechteck {
	private IntegerProperty breite = new SimpleIntegerProperty();
	private IntegerProperty laenge = new SimpleIntegerProperty();
	private IntegerProperty flaeche = new SimpleIntegerProperty();
	private ObjectProperty<Color> color = new SimpleObjectProperty<>();
	private BooleanProperty filled = new SimpleBooleanProperty();

	
	
	public Rechteck() {
		this(200, 200, Color.CORAL);
	}
	public Rechteck(int breite, int laenge, Color color) {
		super();
		setBreite(breite);
		setLaenge(laenge);
	}
	
	public Rechteck(int breite, int laenge, Color color, boolean filled) {
		super();
		setBreite(breite);
		setLaenge(laenge);
	}
	
	public int getBreite() {
		return breite.get();
	}
	public void setBreite(int breite) {
		if(breite < 0) breite = 0;
		if(breite > 400) breite = 400;
		this.breite.set(breite);
	}
	public int getLaenge() {
		return laenge.get();
	}
	public void setLaenge(int laenge) {
		if(laenge < 0) laenge = 0;
		if(laenge > 400) laenge = 400;
		this.laenge.set(laenge);
	}
//	public int getFlaeche() {
//		flaeche.set(getBreite()*getLaenge());
//		return flaeche.get();
//	}
	
	public Color getColor() {
		return color.get();
	}
	public void setColor(Color color) {
		this.color.set(color);
	}
	
	public boolean getFilled() {
		return filled.get();
	}
	
	public void setFilled(boolean filled) {
		this.filled.set(filled);
	}
	
	public IntegerProperty breiteProperty() {
		return breite;
	}
	
	public IntegerProperty laengeProperty() {
		
		return laenge;
	}

	public IntegerProperty flaecheProperty() {
		flaeche.set(getBreite()*getLaenge());
		return flaeche;
	}
	
	public ObjectProperty<Color> colorProperty() {
		return color;
	}
	
	public BooleanProperty filledProperty() {
		return filled;
	}
	@Override
	public String toString() {
		return "Rechteck [this=" + super.toString() + ", breite=" + breite.get() + ", laenge=" + laenge.get() + ", Color="
				+ color.get() + ", filled=" + filled.get() + "]";
	}
	
}

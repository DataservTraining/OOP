
public class B extends A {
	@Override
	public static void testMethode() {

	}
}


public class A {
	public static void testMethode() {
		
	}
}

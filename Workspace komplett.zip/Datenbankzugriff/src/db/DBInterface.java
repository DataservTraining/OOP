package db;

import java.util.List;

import entities.Dept;
import entities.Person;

public interface DBInterface {
	public abstract List<Person> getAllEmployees();
	public abstract List<Dept> getAllDepts();
}

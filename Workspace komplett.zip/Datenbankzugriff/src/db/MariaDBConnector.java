package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entities.Dept;
import entities.Person;

public class MariaDBConnector implements DBInterface{

	@Override
	public List<Person> getAllEmployees() {
		// TODO Automatisch generierter Methodenstub
		return null;
	}

	@Override
	public List<Dept> getAllDepts() {
		System.out.println("MariaDBConnector");
		List<Dept> depts = new ArrayList<>();
		try {
			Connection con = DriverManager.getConnection(DBFactory.getUrl() + DBFactory.getDatabase(), 
							DBFactory.getUser(), DBFactory.getPw());
			Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
			ResultSet rs = stmt.executeQuery("select * from DEPT");
			
			while(rs.next()) {
				Dept dept = new Dept(rs.getString("dname"), rs.getString("loc"), rs.getInt("deptno"));
				depts.add(dept);
			}
			return depts;
		} catch (SQLException e) {
			// TODO Automatisch generierter Erfassungsblock
			e.printStackTrace();
		}
		return depts;
	}

	

}

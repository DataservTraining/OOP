package db;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Properties;

public class DBFactory {
	private static DBInterface instance = null;
	private static String user;
	private static String url;
	private static String pw;
	private static String port;
	private static String database;
	
	
	public static DBInterface getDB() {
		if (instance == null) {
			Properties props = new Properties();
			try {
				props.loadFromXML(new FileInputStream("properties.xml"));
				user = (String) props.get("user");
				url = (String) props.get("url");
				pw = (String) props.get("pw");
				port = (String) props.get("port");
				database = (String) props.get("database");
				Class klasse = Class.forName((String) props.get("class"));
				instance = (DBInterface) klasse.getDeclaredConstructor().newInstance();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (InstantiationException e) {
				// TODO Automatisch generierter Erfassungsblock
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Automatisch generierter Erfassungsblock
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				// TODO Automatisch generierter Erfassungsblock
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Automatisch generierter Erfassungsblock
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				// TODO Automatisch generierter Erfassungsblock
				e.printStackTrace();
			} catch (SecurityException e) {
				// TODO Automatisch generierter Erfassungsblock
				e.printStackTrace();
			}
		}
		
		return instance;
	}


	public static DBInterface getInstance() {
		return instance;
	}


	public static String getUser() {
		return user;
	}


	public static String getUrl() {
		return url;
	}


	public static String getPw() {
		return pw;
	}


	public static String getPort() {
		return port;
	}


	public static String getDatabase() {
		return database;
	}
	
	
}

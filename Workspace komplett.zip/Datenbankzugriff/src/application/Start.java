package application;

import java.util.List;

import db.DBFactory;
import db.DBInterface;
import entities.Dept;

public class Start {

	public static void main(String[] args) {
		DBInterface db = DBFactory.getDB();
		
		List<Dept> depts2 = db.getAllDepts();
		
		depts2.forEach(System.out::println);

	}

}

package application;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class CreateIni {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		Properties props = new Properties();
		props.put("url", "jdbc:mysql://192.168.56.99/");
		props.put("database", "OOP");
		props.put("port", "3306");
		props.put("user", "test");
		props.put("pw", "welcome");
		props.put("class", "db.MariaDBConnector");
		props.storeToXML(new FileOutputStream("properties.xml"), null);

	}

}

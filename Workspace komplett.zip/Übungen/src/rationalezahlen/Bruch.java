package rationalezahlen;

public class Bruch {
	private int zaehler = 0;
	private int nenner = 1;
	
	public Bruch() {
		
	}
	
	public Bruch(int zaehler) {
		this.zaehler = zaehler;
		this.nenner = 1;
	}

	public Bruch(int zaehler, int nenner) {
		this.zaehler = zaehler;
		this.nenner = nenner == 0 ? 1 : nenner;
	}
	
	public void show() {
		System.out.print(zaehler + "/" + nenner);
	}
	
	public Bruch addieren(Bruch bruch) {
		int z = this.zaehler * bruch.nenner + bruch.zaehler * this.nenner;
		int n = this.nenner * bruch.nenner;
		Bruch temp = new Bruch(z, n);
		kuerzen(temp);
		return temp;
	}

	public Bruch multiplizieren(Bruch bruch) {
		int z = this.zaehler * bruch.zaehler;
		int n = this.nenner * bruch.nenner;
		Bruch temp = new Bruch(z, n);
		kuerzen(temp);
		return temp;
	}
	
	private int ggt(int z, int n) {
		    if(n == 0)
		        return z;
		    else return ggt(n, z % n);
	}

	private void kuerzen(Bruch temp) {
		int teiler = ggt(temp.zaehler, temp.nenner);
		temp.zaehler /= teiler;
		temp.nenner /= teiler;
		
	}

}

import java.util.Scanner;

public class Aufgabe2 {

	public static void main(String[] args) {
		int zahl = 0;
		int erg = 1;
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("bitte Zahl eingeben: ");
		zahl = scanner.nextInt();
		
		for(int faktor = zahl; faktor > 1; --faktor) {
			erg *= faktor;
		}
		System.out.println(erg);
		scanner.close();
	}

}

import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;

public class Test {

	public static void main(String[] args) {
//		Locale.setDefault(Locale.US);
		System.out.printf("%,7.4f\n", 23.45);
		System.out.println(23.45);
		test();
		System.out.println("\nFormatiert:"); 
		DecimalFormat format = new DecimalFormat("###000,##");
		System.out.println(format.format(34.56));
		
		Calendar c = new GregorianCalendar();
		   String s1 = String.format("Duke's Birthday: %1$tm %1$te,%1$tY", c);

		   String s2 = String.format("Duke's Birthday: %1$tm %<te,%<tY", c);
		   
		   System.out.println(s1);
		   System.out.println(s2);
	}
	
	public static void test() {
		System.out.printf("%7.4f\n", 23.45);
		System.out.println(23.45);
	}

}

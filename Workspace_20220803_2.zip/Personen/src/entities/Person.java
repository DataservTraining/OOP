package entities;



public class Person {
	public String vorname;
	public String name;
	public int alter;
	
	public Person() {
		this("unbekannt", "unbekannt", 0);
		System.out.println("Standardkonstruktor");
		vorname = "unbekannt";
		name = "unbekannt";
		alter = 0;
	}
	
	public Person(String vorname, String name, int alter) {
		System.out.println("Standardkonstruktor");
		this.vorname = vorname;
		this.name = name;
		this.alter = alter;
	}
	
	public void essen() {
		System.out.println(vorname + " isst.");
	}
	
	public void essen(String nahrung) {
		System.out.println(this.vorname + " isst " + nahrung);
	}
	
	public void show() {
		System.out.printf("Name:  %s %s\n", vorname, name);
		System.out.printf("Alter: %d\n\n" , alter);
	}
}

package application;
import java.util.ArrayList;

import entities.Person;


public class Start {

	public static void main(String[] args) {
		
		Person p = new Person();
		p.show();
		
		p.vorname = "Willi";
		p.name = "Wuff";
		p.alter = 15;
		p.essen();
		String text = "Fleisch";
		p.essen(text);
		
		p.show();
		
		Person p2 = new Person("Donald", "Duck", 180);
//		p2.vorname = "Donald";
//		p2.name = "Duck";
//		p2.alter = 180;
		p2.essen();
		p2.essen("Salat");
		
		p2.show();		
		
		System.out.println(true);

	}

}

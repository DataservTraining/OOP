import java.util.Scanner;

public class Aufgabe5 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		while(true) {
			int preis = 0;
			char tarif = 0;
			
			System.out.println("Tarif A        2,80");
			System.out.println("Tarif B        5,60");
			System.out.println("Tarif C        7,40");
			System.out.println("Bitte waehlen Sie einen Tarif aus: (A, B, C)");
			tarif = scanner.nextLine().charAt(0);
			
			switch(tarif) {
			case 'a':
			case 'A':
				preis = 280;
				break;
			case 'b':
			case 'B':
				preis = 560;
				break;
			case 'c':
			case 'C':
				preis = 740;
				break;
			default: 
				System.out.println("ungültiger Tarif!");
				continue;
			}
			
			while(preis > 0) {
				System.out.printf("Bitte werfen Sie noch %.2f Euro ein\n", preis / 100.0);
				int einwurf = (int)(scanner.nextDouble() * 100);
				if(einwurf != 10 && einwurf != 20 && einwurf != 50 && einwurf != 100 && einwurf != 200 
				   && einwurf != 500 && einwurf != 1000 && einwurf != 2000) {
					System.out.println("Bitte kein Falschgeld!!!");
					continue;
				}
				preis -= einwurf;
			}
			
			if(preis < 0) {
				preis = preis * -1;
				int anzahlMuenzen = preis / 200;
				if(anzahlMuenzen > 0) {
					System.out.printf("%d mal 2,00 Euro\n", anzahlMuenzen);
				}
				 preis %= 200;
				 
				anzahlMuenzen = preis / 100;
				if(anzahlMuenzen > 0) {
					System.out.printf("%d mal 1,00 Euro\n", anzahlMuenzen);
				}
				preis %= 100;
				
				anzahlMuenzen = preis / 50;
				if(anzahlMuenzen > 0) {
					System.out.printf("%d mal 0,50 Euro\n", anzahlMuenzen);
				}
				preis %= 50;
				
				anzahlMuenzen = preis / 20;
				if(anzahlMuenzen > 0) {
					System.out.printf("%d mal 0,20 Euro\n", anzahlMuenzen);
				}
				preis %= 20;
				
				anzahlMuenzen = preis / 10;
				if(anzahlMuenzen > 0) {
					System.out.printf("%d mal 0,10 Euro\n", anzahlMuenzen);
				}
			}
			
			System.out.println("Bitte entnehmen Sie Ihren Fahrschein!");
			scanner.nextLine();
		}

	}

}

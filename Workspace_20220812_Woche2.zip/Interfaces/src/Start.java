
public class Start {

	public static void main(String[] args) {
		TestInterface testI = new B();
		testI.test1();
		testI.test2();

	}

}

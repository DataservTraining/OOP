
public interface TestInterface {
	
	public void test1();
	public void test2();

}

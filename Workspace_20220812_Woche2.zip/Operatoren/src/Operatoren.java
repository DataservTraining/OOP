
public class Operatoren {

	public static void main(String[] args) {
		// Arithmetische Operatoren
		// +, -, *, /, %
		int wert1 = 7, wert2 = 2;
		double wert3 = 7.9, wert4 = 3.6;
		double erg = 0;
		erg = wert1 % wert2;
		System.out.println("Ergebnis: " + erg);
		
		erg = wert3 % wert4;
		System.out.println("Ergebnis: " + erg);
		System.out.println(erg > 0.699999999999999999999 && erg < 0.7000001);
		
		// Inkrement- und Dekrementoperator
		// ++, --
		erg = (--wert1 + 
				wert2) * 
				++wert1;
		System.out.println("erg: " + erg +"\twert1: " + wert1);
		
		// Relationale Operatoren
		// <, >, <=, >=, ==, !=
		
		// &&, & (und); ||, | (oder); ^ (exclusive oder, xor); ! (nicht)
		
		boolean ok = wert1 < wert2 & wert3++ > wert4;
		
		// Zuweisungsoperatoren
		// =, +=, -=, *=, /=, %= 
		// &=, |=, ^=, ~=, <<=, >>=, >>>=
		
		wert1 += 10;  // wert1 = wert1 + 10;
		wert1 *= wert2 + 4; // wert1 = wert1 * (wert2 + 4)

	}

}

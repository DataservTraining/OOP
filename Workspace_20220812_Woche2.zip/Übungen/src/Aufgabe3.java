import java.util.Scanner;

public class Aufgabe3 {

	public static void main(String[] args) {
		final int ADDIEREN = 1;
		final int SUBTRAHIEREN = 2;
		final int MULTIPLIZIEREN = 3;
		final int DIVIDIEREN = 4;
		final int POTENZIEREN = 5;
		final int FAKULTAET = 6;
		
		double zahl2 = 0;
		double ergebnis = 0;
		char opChar = 0;
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("bitte 1. Zahl eingeben: ");
		double zahl1 = scanner.nextDouble();
		System.out.println("bitte Operator eingeben: (1=+, 2=-, ...)");
		
		int op = scanner.nextInt();
		
		if(op != FAKULTAET) {
			System.out.println("bitte 2. Zahl eingeben: ");
			zahl2 = scanner.nextDouble();
		}
		
		switch(op) {
		case ADDIEREN:
				opChar = '+';
				ergebnis = zahl1 + zahl2;
				break;
		case SUBTRAHIEREN:
			opChar = '-';
			ergebnis = zahl1 - zahl2;
			break;
		case MULTIPLIZIEREN:
			opChar = '*';
			ergebnis = zahl1 * zahl2;
			break;
		case DIVIDIEREN:
			opChar = '/';
			if(zahl2 != 0) {
				ergebnis = zahl1 / zahl2;
			} else {
				System.out.println("Division durch 0 nicht erlaubt!");
			}
			break;
		case POTENZIEREN:
			opChar = '^';
					ergebnis = 1;
					for(int zaehler = 1; zaehler <= zahl2; ++zaehler) {
						ergebnis *= zahl1;
					}
					break;
		case FAKULTAET:
			opChar = '!';
			ergebnis = 1;
			for(int faktor = (int)zahl1; faktor > 1; --faktor) {
				ergebnis *= faktor;
			}
			break;
		default:
			System.out.println("keine gültige Rechenoperation");
		}
		
		if(op != FAKULTAET) {
			System.out.printf("Ergebnis: %.3f %c %.3f = %.3f\n ", zahl1, opChar, zahl2, ergebnis);
		} else if(op == FAKULTAET) {
			System.out.printf("Ergebnis: %.0f%c = %.0f\n ", zahl1, opChar, ergebnis);
		}
	}

}

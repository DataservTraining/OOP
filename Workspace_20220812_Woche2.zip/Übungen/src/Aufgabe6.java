import java.util.Scanner;

public class Aufgabe6 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Programmierer? (j / n) ");
		char programmierer = scanner.nextLine().charAt(0);

		System.out.println("Anzahl Jahre ");
		int anzahlJahre = scanner.nextInt();

		if (programmierer == 'j' && anzahlJahre < 3) {
			System.out.println("486er");
		} else if (programmierer == 'j' && anzahlJahre >= 3) {
			System.out.println("Pentium");
		} else if (programmierer == 'n' && anzahlJahre < 3) {
			System.out.println("386er");
		} else {
			System.out.println("MAC");
		}

		if (programmierer == 'j') {
			if(anzahlJahre < 3) {
				System.out.println("486er");
			} else {
				System.out.println("Pentium");
			}
		} else if (programmierer == 'n') {
			if(anzahlJahre < 3) {
				System.out.println("386er");
			} else {
				System.out.println("MAC");
			}
		} 
		scanner.close();
	}

}

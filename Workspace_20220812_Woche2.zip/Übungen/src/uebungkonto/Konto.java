package uebungkonto;

public class Konto {
	private String inhaber;
	private long kontoNummer;
	private double saldo;
	private double dispo;
	private static int anzahl;
	
	public Konto() {
		this("unbekannt", 0L, 0.0);
	}

	public Konto(long kontoNummer) {
		this("unbekannt", 0L, 0.0);
	}

	public Konto(String inhaber, long kontoNummer) {
		this("unbekannt", 0L, 0.0);
	}

	public Konto(String inhaber, long kontoNummer, double dispo) {
		this.inhaber = inhaber;
		this.kontoNummer = kontoNummer;
		this.dispo = dispo;
		this.saldo = 0;
		++anzahl;
	}
	


//	@Override
//	protected void finalize() throws Throwable {
//		// TODO Automatisch generierter Methodenstub
//		super.finalize();
//	}

	public static int getAnzahl() {
		return anzahl;
	}
	
	public String getInhaber() {
		return inhaber;
	}

	public void setInhaber(String inhaber) {
		this.inhaber = inhaber;
	}

	public double getDispo() {
		return dispo;
	}

	public void setDispo(double dispo) {
		if(dispo < 0) {
			System.out.println("ungültiger WErt für Dispo: " + dispo);
			return;
		}
		this.dispo = dispo;
	}

	public long getKontoNummer() {
		return kontoNummer;
	}

	public double getSaldo() {
		return saldo;
	}
	
	
	public void display() {
		System.out.printf("Kontonummer:    %d\n", kontoNummer);
		System.out.printf("Inhaber:        %s\n", inhaber);
		System.out.printf("Saldo:          %.2f Euro\n", saldo);
		System.out.printf("Dispo:          %.2f Euro\n", dispo);
	}
	
	public void einzahlen(double betrag) {
		saldo += betrag;
	}
	
	public double abheben(double betrag) {
		if(saldo + dispo > betrag) {
			saldo -= betrag;
			return betrag;
		} else {
			return saldo + dispo;
		}
	}
	
}

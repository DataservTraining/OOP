
public class Abteilung {

}

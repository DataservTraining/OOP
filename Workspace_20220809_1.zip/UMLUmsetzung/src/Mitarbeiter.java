
public class Mitarbeiter extends Person{

}


public class B implements TestInterface{

	@Override
	public void test1() {
		System.out.println("B.test1()");
		
	}

	@Override
	public void test2() {
		System.out.println("B.test2()");
	}

}

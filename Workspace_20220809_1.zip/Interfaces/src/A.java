
public class A implements TestInterface{

	@Override
	public void test1() {
		System.out.println("A.test1()");
		
	}

	@Override
	public void test2() {
		System.out.println("A.test2()");
		
	}

}

package uebungkonto;

public class Start {

	public static void main(String[] args) {
		System.out.println("Anzahl Konten: " + Konto.getAnzahl());
		Konto k1 = new Konto("Donald Duck", 12388728678L, 1000.0);
		System.out.println("Anzahl Konten: " + Konto.getAnzahl());
		Konto k2 = new Konto("Daisy Duck", 12388728679L, 1000.0);
		System.out.println("Anzahl Konten: " + Konto.getAnzahl());
		Konto k3 = new Konto("Willi Wuff", 12388728698L, 1000.0);
		System.out.println("Anzahl Konten: " + Konto.getAnzahl());
		Konto k4 = new Konto("Donald Duck", 873264846L, 2000.0);
		System.out.println("Anzahl Konten: " + Konto.getAnzahl());
		
		k1.display();
		k2.display();
		k3.display();
		k4.display();
		
		

	}

}

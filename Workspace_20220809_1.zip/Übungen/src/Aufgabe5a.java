import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Aufgabe5a {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Map<Integer, Integer> muenzen = new LinkedHashMap<>();
		// Aufbau des Münzvorrats
		muenzen.put(200, 20);
		muenzen.put(100, 20);
		muenzen.put(50, 20);
		muenzen.put(20, 20);
		muenzen.put(10, 20);
		muenzen.put(500, 20);
		muenzen.put(1000, 20);
		muenzen.put(2000, 20);

		while (true) {
			int preis = 0;
			char tarif = 0;
			// Ausgabe der Tarife
			System.out.println("Tarif A        2,80");
			System.out.println("Tarif B        5,60");
			System.out.println("Tarif C        7,40");
			System.out.println("Bitte waehlen Sie einen Tarif aus: (A, B, C)");
			// Einlesen des Tarifs
			tarif = scanner.nextLine().charAt(0);
			// Prüfen des Tarifs und zuweisen des Preises in Cent
			switch (tarif) {
			case 'a':
			case 'A':
				preis = 280;
				break;
			case 'b':
			case 'B':
				preis = 560;
				break;
			case 'c':
			case 'C':
				preis = 740;
				break;
			default:
				System.out.println("ungültiger Tarif!");
				// Bei ungültigem Tarif wiederholen
				continue;
			}

			// Einlesen des Einwurfs bis der Preis bezahlt ist
			while (preis > 0) {
				System.out.printf("Bitte werfen Sie noch %.2f Euro ein\n", preis / 100.0);
				// Umwandlung des Einwurfs von double nach int
				int einwurf = (int) (scanner.nextDouble() * 100);
				// Überprüfung des Einwurfs auf gültiges Zahlungsmittel
				if (einwurf != 10 && einwurf != 20 && einwurf != 50 && einwurf != 100 && einwurf != 200
						&& einwurf != 500 && einwurf != 1000 && einwurf != 2000) {
					System.out.println("Bitte kein Falschgeld!!!");
					continue;
				}
				// Einfügen des Einwurfs in den Zahlungsmittelvorrat
				int value = muenzen.get(einwurf);
				muenzen.put(einwurf, ++value);
				// Reduzierung des Preises um den Einwurf
				preis -= einwurf;
			}
//System.out.println(muenzen);
			if (preis < 0) {
				preis = preis * -1;
				
				// Iteration über die Münzen im Vorrat
				for (Map.Entry<Integer, Integer> eintrag : muenzen.entrySet()) {
					int key = eintrag.getKey();
					int value = eintrag.getValue();
					int anzahlMuenzen = preis / key;
					// Wenn nur noch Scheine, dann Abbruch
					if(key > 200) break;
					if (anzahlMuenzen > 0 && value > anzahlMuenzen) {
						System.out.printf("%d mal %.2f Euro\n", anzahlMuenzen, (key/100.0) );
						// Reduzierung der Anzahl Münzen im Vorrat
						eintrag.setValue(value - anzahlMuenzen);
						preis %= key;
					}
				}
			}

			System.out.println("Bitte entnehmen Sie Ihren Fahrschein!");
			scanner.nextLine();
		}

	}

}

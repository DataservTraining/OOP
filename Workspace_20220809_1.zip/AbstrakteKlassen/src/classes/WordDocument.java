package classes;

public class WordDocument extends Document{

	@Override
	public void save() {
		System.out.println("Word-Dokument gespeichert.");
	}

}

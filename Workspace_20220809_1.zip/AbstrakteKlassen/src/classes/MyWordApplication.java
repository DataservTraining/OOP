package classes;

public class MyWordApplication extends AbstractApplication{

	@Override
	protected Document createDocument() {
		return new WordDocument();
	}

}



public class Fahrzeug {

	private String hersteller;
	private String farbe;
	protected int anzahlSitze;
	protected int ps;
	protected double verbrauchPro100;
	protected int maxTankinhalt;
	private double aktTankinhalt;
	private double tagesKilometer;
	private double gesamtKilometer;
	
	public Fahrzeug() {
		this("unbekannt", "unbekannt", 0, 0, 0.0, 0);
	}
	
	public Fahrzeug(String hersteller, String farbe, int anzahlSitze, int ps, double verbrauchPro100, 
			int maxTankinhalt) {
		super();
		this.hersteller = hersteller;
		this.farbe = farbe;
		setAnzahlSitze(anzahlSitze);
		setPs(ps);
		setVerbrauchPro100(verbrauchPro100);
		setMaxTankinhalt(maxTankinhalt);
		this.aktTankinhalt = 0;
		this.tagesKilometer = 0;
		this.gesamtKilometer = 0;
	}

	public String getHersteller() {
		return hersteller;
	}

	public void setHersteller(String hersteller) {
		this.hersteller = hersteller;
	}

	public String getFarbe() {
		return farbe;
	}

	public void setFarbe(String farbe) {
		this.farbe = farbe;
	}

	public int getAnzahlSitze() {
		return anzahlSitze;
	}

	public void setAnzahlSitze(int anzahlSitze) {
		if(anzahlSitze < 1 || anzahlSitze > 100) {
			System.out.println("ungültige Anzahl Sitze!" + anzahlSitze);
			return;
		}
		this.anzahlSitze = anzahlSitze;
	}

	public int getPs() {
		return ps;
	}

	public void setPs(int ps) {
		if(ps < 1 || ps > 800) {
			System.out.println("ungültiger Wert für PS!" + ps);
			return;
		}
		this.ps = ps;
	}
	
	

	public double getVerbrauchPro100() {
		return verbrauchPro100;
	}

	public void setVerbrauchPro100(double verbrauchPro100) {
		if(verbrauchPro100 < 0 || verbrauchPro100 > 100) {
			System.out.println("ungültiger Wert für Verbrauch / 100 km!" + verbrauchPro100);
			return;
		}
		this.verbrauchPro100 = verbrauchPro100;
	}

	public int getMaxTankinhalt() {
		return maxTankinhalt;
	}

	public void setMaxTankinhalt(int maxTankinhalt) {
		if(maxTankinhalt < 1 || maxTankinhalt > 1000) {
			System.out.println("ungültiger Wert für max. Tankinhialt! " + maxTankinhalt);
			return;
		}
		this.maxTankinhalt = maxTankinhalt;
	}

	public double getAktTankinhalt() {
		return aktTankinhalt;
	}

	public double getTagesKilometer() {
		return tagesKilometer;
	}

	public double getGesamtKilometer() {
		return gesamtKilometer;
	}
	
	public double fahren(double km) {
		double rw = reichweite();
		if(rw >= km) {
			aktTankinhalt -= verbrauch(km);
			tagesKilometer += km;
			gesamtKilometer += km;
			return 0;
		} else {
			aktTankinhalt = 0;
			tagesKilometer += rw;
			gesamtKilometer += rw;
			return km - rw;
		}
	}
	
	public double reichweite() {
		return aktTankinhalt / verbrauchPro100 * 100;
	}
	
	private double verbrauch(double km) {
		return km * verbrauchPro100 / 100;
	}
	
	public void tanken() {
		aktTankinhalt = maxTankinhalt;
		tagesKilometer = 0;
	}
	
	public void tanken(int liter) {
		if((liter + aktTankinhalt) > maxTankinhalt || liter < 0) {
			System.out.println("ungültiger WErt für Liter: " + liter);
			return;
		}
		aktTankinhalt += liter;
		tagesKilometer = 0;
	}
	
	public void wartungsplanDrucken() {
		System.out.println("Beleuchtung prüfen");
		System.out.println("Bremsen prüfen");
		System.out.println("---------------------------------------");
	}

	public void show() {
		System.out.printf("Hersteller:      %s\n", hersteller);
		System.out.printf("Farbe:           %s\n", farbe);
		System.out.printf("Anzahl Sitze:    %d\n", anzahlSitze );
		System.out.printf("PS:              %d\n", ps);
		System.out.printf("Verbrauch:       %.1f l/100km\n", verbrauchPro100);
		System.out.printf("max. Tankinhalt: %d l\n", maxTankinhalt);
		System.out.printf("akt. Tankinhalt: %.1f l\n", aktTankinhalt);
		System.out.printf("Tageskilometer:  %.1f\n", tagesKilometer);
		System.out.printf("Gesamtkilometer: %.1f\n", gesamtKilometer);
		
		System.out.println("--------------------------------------");
	}

}

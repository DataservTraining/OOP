
public class Flugzeug extends Fahrzeug {

	private int spannweite;
	private int anzahlTriebwerke;

	public Flugzeug() {
		this("unbekannt", "unbekannt", 0, 0, 0.0, 0, 0, 0);
	}

	public Flugzeug(String hersteller, String farbe, int anzahlSitze, int ps, double verbrauchPro100, int maxTankinhalt,
			int anzahlTriebwerke, int spannweite) {
		super(hersteller, farbe, anzahlSitze, ps, verbrauchPro100, maxTankinhalt);
		setAnzahlTriebwerke(anzahlTriebwerke);
		setSpannweite(spannweite);
	}

	@Override
	public void setAnzahlSitze(int anzahlSitze) {
		if (anzahlSitze < 1 || anzahlSitze > 600) {
			System.out.println("ungültige Anzahl Sitze!" + anzahlSitze);
			return;
		}
		this.anzahlSitze = anzahlSitze;
	}

	@Override
	public void setPs(int ps) {
		if (ps < 1 || ps > 100000) {
			System.out.println("ungültiger Wert für PS!" + ps);
			return;
		}
		this.ps = ps;
	}

	@Override
	public void setVerbrauchPro100(double verbrauchPro100) {
		if (verbrauchPro100 < 0 || verbrauchPro100 > 100000) {
			System.out.println("ungültiger Wert für Verbrauch / 100 km!" + verbrauchPro100);
			return;
		}
		this.verbrauchPro100 = verbrauchPro100;
	}

	@Override
	public void setMaxTankinhalt(int maxTankinhalt) {
		if (maxTankinhalt < 1 || maxTankinhalt > 100000) {
			System.out.println("ungültiger Wert für max. Tankinhialt! " + maxTankinhalt);
			return;
		}
		this.maxTankinhalt = maxTankinhalt;
	}

	public void starten() {

	}

	public void landen() {

	}

	public int getSpannweite() {
		return spannweite;
	}

	public void setSpannweite(int spannweite) {
		this.spannweite = spannweite;
	}

	public int getAnzahlTriebwerke() {
		return anzahlTriebwerke;
	}

	public void setAnzahlTriebwerke(int anzahlTriebwerke) {
		this.anzahlTriebwerke = anzahlTriebwerke;
	}

	@Override
	public void wartungsplanDrucken() {
		super.wartungsplanDrucken();
		System.out.println("Triebwerke prüfen");
		System.out.println("steuerung prüfen");
		System.out.println("*************************");
	}

	public void show() {
		super.show();
		System.out.printf("Spannweite:        %d\n", spannweite);
		System.out.printf("Anzahl Triebwerke: %d\n", anzahlTriebwerke);
	}

}

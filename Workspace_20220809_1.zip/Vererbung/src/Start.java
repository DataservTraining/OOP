
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Start {

	public static void main(String[] args) {

		Fahrzeug fahrzeug = null;
		System.out.println("Flugzeug oder Fahrzeug?");
		Scanner scanner = new Scanner(System.in);
		int antwort = scanner.nextInt();
		if(antwort == 1) {
			fahrzeug = new Fahrzeug("Audi", "Schwarz", 150, 190, 8.5, 95);
//			fahrzeug.show();
		} else {
			
			fahrzeug = new Flugzeug();
			((Flugzeug)fahrzeug).setSpannweite(45);
			System.out.println(((Flugzeug)fahrzeug).getSpannweite());
//			fahrzeug.show();
		}
		
		fahrzeug.show();
		
		List<Fahrzeug> fahrzeuge = new LinkedList<>();
		
		fahrzeuge.add(fahrzeug);
		fahrzeuge.add(new Fahrzeug("BMW", "Blau", 5, 210, 10.0, 100));
		fahrzeuge.add(new Flugzeug("Boing", "Silber", 130, 12000, 1000, 30000, 4, 90));
		
		for(Fahrzeug f : fahrzeuge) {
			f.wartungsplanDrucken();
		}
		
		
		
	}

}
